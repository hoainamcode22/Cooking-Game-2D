# GENERATED HOUSE ART — Cooking-Game-2D (đợt 3: 5 nhà × 6 stage)

Sinh bằng code vector theo `production/art-handoff/STYLE_CONTRACT.md`. Không dùng image_gen.

## 6 stage
1 móng + khung sườn + dàn giáo · 2 bắt đầu xây (tường 1/3 + vật liệu) · 3 xây nửa (mái lợp một phần,
dàn giáo một bên) · **4 HOÀN CHỈNH** · 5 gói hộp quà · 6 hộp bung lộ nhà

## QC — 5/5 PASS
- 0 sprite vượt ô 512px ✓  (đây là lỗi khó nhất: dàn giáo + hộp quà rộng hơn nhà)
- Viền trắng 0.00% trên cả 30 file ✓
- Hue outline 23.3–27.1 ✓
- Baseline chung y=470 mọi stage → nhà KHÔNG nhảy giữa các stage ✓

## Luật shared-crop-rect đã tuân thủ
`MayAnimSetupTool.cs:39-44` ghi: bbox riêng từng frame làm công trình nhảy 12px.
Ở đây cả 6 stage cùng baseline và cùng tâm x → chuyển stage không giật.

## Nhận diện 5 nhà (giữ đúng bản gốc)
| | Mái | Tường | Màu gói quà |
|---|---|---|---|
| House_01 | gambrel xanh ngọc `#3F8478` | ivory board-and-batten | san hô + vàng |
| House_02 | gable dốc navy `#2E3648` | clapboard xanh xám | vàng hổ phách + đỏ |
| House_03 | gable rộng nâu socola `#6B4126` | lap siding hổ phách `#D9963C` | xanh rừng + vàng |
| House_04 | hip kem `#EEDCB6` | coral `#E0714F` | mận + kem |
| House_05 | gable xanh rêu `#7EA05C` | olive + khung gỗ cam nâu | đỏ thẫm + vàng |

## Stage 5–6 gần như KHÔNG cần code mới
`ConstructionCompleteFX.BuildGiftBox()` đã dựng hộp + ruy băng + nơ tự khớp footprint,
timeline 2.10s (pop 0.26s → hiện nhà → mở 0.34s + 6 bóng bay). Thay 3 slot art
`GiftBoxSide` / `Ribbon` / `Rosette` trong `ConstructionArtKit.asset` là nâng cấp cho MỌI công trình,
**không sửa một dòng code**. Sprite stage 5/6 ở đây là bản fidelity cao hơn cho từng nhà.

## Còn thiếu (cần code)
`ConstructionSiteVisuals.Build()` không nhận tham số tiến độ, `PlaceableItemData` không có field stage.
Muốn stage 1→3 tự đổi theo timer 30s phải thêm code — chưa làm, chờ duyệt.
