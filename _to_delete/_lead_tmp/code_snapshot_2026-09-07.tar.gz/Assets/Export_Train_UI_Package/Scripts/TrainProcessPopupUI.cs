using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ExportTrainUIPackage
{
    public class TrainProcessPopupUI : MonoBehaviour
    {
        public static TrainProcessPopupUI Instance { get; private set; }

        private const string SpritesDir = "Assets/Export_Train_UI_Package/Sprites";

        [Header("Header & Panels")]
        public Image imgFrameWood;
        public Image imgPanelPaper;
        public Image imgRibbonBanner;
        public TextMeshProUGUI txtTitle;
        public Button btnClose;

        [Header("Mini Track & Train Animation")]
        public RectTransform trackBox;
        public Image imgTrackBox;
        public RectTransform miniTrain;
        public Image imgMiniTrain;
        public Image imgSmokePuff;

        [Header("Status & Timer")]
        public TextMeshProUGUI txtStatus;
        public GameObject timerBox;
        public Image imgTimerBox;
        public TextMeshProUGUI txtTimer;
        public Image imgProgressBar;

        [Header("Sent Cargo Chips")]
        public GameObject cargoChipsContainer;
        public Image[] chipContainers = new Image[3];
        public Image[] chipIcons = new Image[3];
        public TextMeshProUGUI[] chipAmounts = new TextMeshProUGUI[3];

        [Header("Buttons")]
        public Button btnSpeedUp;
        public Image imgSpeedUp;
        public TextMeshProUGUI txtSpeedUp;
        public Button btnRaGa;
        public Image imgRaGa;
        public TextMeshProUGUI txtRaGa;

        [Header("Timer State — đồng bộ từ TrainManager, KHÔNG tự đếm")]
        public float totalDuration = 600f;
        public float remainingTime = 600f;

        /// <summary>Tàu đã về chưa — đọc thẳng state máy chủ TrainManager.</summary>
        public bool isArrived
        {
            get
            {
                var mgr = TrainManager.Instance;
                if (mgr != null)
                    return mgr.State == global::TrainState.RewardArriving
                        || mgr.State == global::TrainState.RewardReadyToCollect;
                return remainingTime <= 0f;
            }
        }

        private global::TrainState _lastShownState = (global::TrainState)(-1);
        private bool _popupInputLockHeld;

        private void Awake()
        {
            // [VÒNG 13] Guard trùng: scene từng có 2-3 bản popup này (do FindPopupCanvas chọn
            // nhầm canvas). Bản Awake sau cùng ghi đè Instance, bản trước thành "popup ma" có
            // nút X chết. Giữ bản ĐẦU TIÊN, bản sau chỉ tự ẩn chứ KHÔNG Destroy — destroy sẽ
            // làm rỗng reference ai đó đã kéo tay trong Inspector.
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning($"[TrainProcessPopupUI] Phát hiện bản TRÙNG tại '{name}' — tự ẩn. Chạy Tools/Farm Game/Train/★ Dọn popup tàu bị nhân bản để dọn hẳn.");
                gameObject.SetActive(false);
                return;
            }
            Instance = this;
            EnsureCanvasSetup();
            AutoBindComponents();
            if (btnClose != null)
                btnClose.onClick.AddListener(ClosePopup);
            if (btnSpeedUp != null)
                btnSpeedUp.onClick.AddListener(OnSpeedUpClicked);
            if (btnRaGa != null)
                btnRaGa.onClick.AddListener(OnRaGaClicked);
        }

        private void EnsureCanvasSetup()
        {
            var c = GetComponent<Canvas>();
            if (c == null) c = gameObject.AddComponent<Canvas>();
            c.overrideSorting = true;
            c.sortingOrder = 420;
            if (GetComponent<GraphicRaycaster>() == null)
                gameObject.AddComponent<GraphicRaycaster>();
        }

        private void OnEnable()
        {
            EnsureCanvasSetup();
            ApplyThemeSprites();
        }

        private void Update()
        {
            if (!gameObject.activeInHierarchy) return;

            var mgr = TrainManager.Instance;
            if (mgr == null) return;

            // Chuyến đã kết thúc hẳn (tàu mới vào ga / đang rời) → popup này hết vai trò
            if (mgr.State == global::TrainState.WaitingForLoad ||
                mgr.State == global::TrainState.RewardDeparting)
            {
                ClosePopup();
                return;
            }

            if (mgr.State == global::TrainState.Processing)
            {
                remainingTime = mgr.TripRemainingTime;
                totalDuration = Mathf.Max(1f, mgr.TripTotalDuration);
                UpdateTimerAndTrainPosition();
                UpdateSpeedUpCost();
            }
            else if (_lastShownState != mgr.State)
            {
                RefreshUI(); // tàu vừa về → chuyển giao diện "TÀU ĐÃ VỀ!"
            }
            _lastShownState = mgr.State;
        }

        /// <summary>Cập nhật giá tăng tốc theo thời gian còn lại (công thức hệ xây dựng).</summary>
        private void UpdateSpeedUpCost()
        {
            if (txtSpeedUp == null || TrainManager.Instance == null) return;
            txtSpeedUp.text = $"TĂNG TỐC · {TrainManager.Instance.SpeedUpCost}";
        }

        public void OpenPopup(float duration = 0f)
        {
            var mgr = TrainManager.Instance;
            if (mgr != null && mgr.State == global::TrainState.Processing)
            {
                totalDuration = Mathf.Max(1f, mgr.TripTotalDuration);
                remainingTime = mgr.TripRemainingTime;
            }
            else if (duration > 0f)
            {
                totalDuration = duration;
                remainingTime = duration;
            }
            gameObject.SetActive(true);
            AcquirePopupInputBlock();
            ApplyThemeSprites();
            RefreshUI();
        }

        public void ClosePopup()
        {
            ReleasePopupInputBlock();
            gameObject.SetActive(false);
        }

        private void OnDisable()
        {
            ReleasePopupInputBlock();
        }

        private void AcquirePopupInputBlock()
        {
            FarmInputLock.SetPopupRaycastBlock(gameObject, true);
            if (!_popupInputLockHeld)
            {
                FarmInputLock.RegisterPopupOpen();
                _popupInputLockHeld = true;
            }
        }

        private void ReleasePopupInputBlock()
        {
            FarmInputLock.SetPopupRaycastBlock(gameObject, false);
            if (_popupInputLockHeld)
            {
                FarmInputLock.RegisterPopupClose();
                _popupInputLockHeld = false;
            }
        }

        public void ApplyThemeSprites()
        {
            AutoBindComponents();

            if (imgFrameWood != null)
            {
                TrainSpriteLoader.Assign(imgFrameWood, $"{SpritesDir}/popup_frame_wood.png");
                imgFrameWood.type = Image.Type.Sliced;
                imgFrameWood.color = Color.white;
            }

            if (imgPanelPaper != null)
            {
                TrainSpriteLoader.Assign(imgPanelPaper, $"{SpritesDir}/popup_panel_paper.png");
                imgPanelPaper.type = Image.Type.Sliced;
                imgPanelPaper.color = Color.white;
            }

            if (imgRibbonBanner != null)
            {
                TrainSpriteLoader.Assign(imgRibbonBanner, $"{SpritesDir}/ribbon_banner_gold.png");
                imgRibbonBanner.type = Image.Type.Sliced;
                imgRibbonBanner.color = Color.white;
            }

            if (btnClose != null)
            {
                var img = btnClose.GetComponent<Image>();
                if (img != null)
                {
                    Sprite sprClose = UIStandardSprites.Close;         // WP-D2b: nút đóng chuẩn
                    if (sprClose != null) { img.sprite = sprClose; img.type = Image.Type.Sliced; img.color = Color.white; }
                    else TrainSpriteLoader.Assign(img, "Assets/thietke/Redesign popup nhiệm vụ game/UnifiedTaskPopup_Redesign/assets/btnX.png", "Assets/Assetsgame/btnX.png");
                    img.preserveAspect = true;
                }
            }

            if (imgTrackBox != null)
            {
                TrainSpriteLoader.Assign(imgTrackBox, $"{SpritesDir}/mini_train_track_bg.png");
                imgTrackBox.type = Image.Type.Sliced;
                imgTrackBox.color = Color.white;
            }

            if (imgMiniTrain != null)
            {
                TrainSpriteLoader.Assign(imgMiniTrain, $"{SpritesDir}/train_popup_mini_horizontal.png");
                imgMiniTrain.preserveAspect = true;
                imgMiniTrain.color = Color.white;
            }

            if (imgTimerBox != null)
            {
                TrainSpriteLoader.Assign(imgTimerBox, $"{SpritesDir}/timer_box_dark.png");
                imgTimerBox.type = Image.Type.Sliced;
                imgTimerBox.color = Color.white;
            }

            if (imgSpeedUp != null)
            {
                TrainSpriteLoader.Assign(imgSpeedUp, $"{SpritesDir}/btn_blue_gem_3d.png");
                imgSpeedUp.type = Image.Type.Sliced;
                imgSpeedUp.color = Color.white;
            }

            // Icon cánh tốc độ (asset sprite-forge 2026-08-26) — tự tạo child nếu prefab chưa có
            if (btnSpeedUp != null)
            {
                var wingTr = btnSpeedUp.transform.Find("Icon_Wing");
                if (wingTr == null)
                {
                    var wingGo = new GameObject("Icon_Wing", typeof(RectTransform));
                    wingGo.transform.SetParent(btnSpeedUp.transform, false);
                    wingTr = wingGo.transform;

                    var wingRt = (RectTransform)wingTr;
                    wingRt.anchorMin = new Vector2(0f, 0.5f);
                    wingRt.anchorMax = new Vector2(0f, 0.5f);
                    wingRt.pivot = new Vector2(0.5f, 0.5f);
                    wingRt.anchoredPosition = new Vector2(34f, 0f);
                    wingRt.sizeDelta = new Vector2(40f, 40f);
                }

                var wingImg = wingTr.GetComponent<Image>();
                if (wingImg == null) wingImg = wingTr.gameObject.AddComponent<Image>();
                wingImg.raycastTarget = false;
                wingImg.preserveAspect = true;
                TrainSpriteLoader.Assign(wingImg, $"{SpritesDir}/icon_speedup_wing.png");
                wingImg.enabled = wingImg.sprite != null; // build không load được → ẩn, không ô trắng
            }

            if (imgRaGa != null)
            {
                TrainSpriteLoader.Assign(imgRaGa, $"{SpritesDir}/btn_green_3d.png");
                imgRaGa.type = Image.Type.Sliced;
                imgRaGa.color = Color.white;
            }

            for (int i = 0; i < chipContainers.Length; i++)
            {
                if (chipContainers[i] != null)
                {
                    TrainSpriteLoader.Assign(chipContainers[i], $"{SpritesDir}/bubble_cargo_req.png");
                    chipContainers[i].type = Image.Type.Sliced;
                    chipContainers[i].color = Color.white;
                }
            }
        }

        public void RefreshUI()
        {
            ApplyThemeSprites();

            if (isArrived)
            {
                if (txtTitle != null) txtTitle.text = "TÀU ĐÃ VỀ!";
                if (txtStatus != null)
                {
                    txtStatus.text = "Tàu đã về — có hàng cho bạn!";
                    txtStatus.color = new Color(0.30f, 0.56f, 0.11f);
                }
                if (txtTimer != null) txtTimer.text = "00:00";
                if (btnSpeedUp != null) btnSpeedUp.gameObject.SetActive(false);
                if (btnRaGa != null) btnRaGa.gameObject.SetActive(true);
            }
            else
            {
                if (txtTitle != null) txtTitle.text = "ĐANG VẬN CHUYỂN";
                if (txtStatus != null)
                {
                    txtStatus.text = "Đang vận chuyển...";
                    txtStatus.color = new Color(0.36f, 0.20f, 0.09f);
                }
                if (btnSpeedUp != null) btnSpeedUp.gameObject.SetActive(true);
                if (btnRaGa != null) btnRaGa.gameObject.SetActive(false);
            }

            // Chips "Hàng đã gửi" — đọc snapshot chuyến THẬT từ TrainManager
            var sent = TrainManager.Instance != null ? TrainManager.Instance.LastSentCargo : null;
            int chipIdx = 0;
            for (int i = 0; i < chipContainers.Length; i++)
            {
                bool has = false;
                if (sent != null)
                {
                    while (chipIdx < sent.Length &&
                           (sent[chipIdx] == null || sent[chipIdx].mode != global::TrainWagonSlotMode.CargoRequest))
                        chipIdx++;

                    if (chipIdx < sent.Length)
                    {
                        var s = sent[chipIdx];
                        if (chipAmounts[i] != null) chipAmounts[i].text = $"x{s.requiredAmount}";
                        if (chipIcons[i] != null)
                        {
                            chipIcons[i].sprite  = s.icon;
                            chipIcons[i].enabled = s.icon != null;
                            chipIcons[i].color   = Color.white;
                        }
                        has = true;
                        chipIdx++;
                    }
                }
                if (chipContainers[i] != null) chipContainers[i].gameObject.SetActive(has);
            }

            UpdateTimerAndTrainPosition();
        }

        private void UpdateTimerAndTrainPosition()
        {
            int mins = Mathf.FloorToInt(remainingTime / 60f);
            int secs = Mathf.FloorToInt(remainingTime % 60f);
            if (txtTimer != null)
                txtTimer.text = $"{mins:00}:{secs:00}";

            float progress = Mathf.Clamp01(1f - (remainingTime / totalDuration));
            if (imgProgressBar != null)
                imgProgressBar.fillAmount = progress;

            if (miniTrain != null)
            {
                float posX = Mathf.Lerp(-140f, 140f, progress);
                miniTrain.anchoredPosition = new Vector2(posX, miniTrain.anchoredPosition.y);
            }
        }

        private void OnSpeedUpClicked()
        {
            var mgr = TrainManager.Instance;
            if (mgr == null) return;

            // TrySpeedUp tự trừ kim cương (RushCostFor) — không đủ thì tự hiện hint, không skip
            if (mgr.TrySpeedUp())
            {
                remainingTime = 0f;
                RefreshUI();
            }
        }

        private void OnRaGaClicked()
        {
            ClosePopup();
            // [VONG 6 - 06/09] Dung LayPopupThat() de khong bao gio vo phai mot component
            // MasterPopupUI di lac tren toa tau (nguon goc vu "3 popup de nhau").
            var masterPopup = TrainStationMasterPopupUI.LayPopupThat();

            if (masterPopup != null)
            {
                masterPopup.OpenPopup(TrainState.RewardReadyToCollect);
            }
        }

        public void AutoBindComponents()
        {
            if (imgFrameWood == null) imgFrameWood = GetComponent<Image>();
            if (imgPanelPaper == null) imgPanelPaper = transform.Find("Paper_Panel")?.GetComponent<Image>();
            if (imgRibbonBanner == null) imgRibbonBanner = transform.Find("Ribbon_Banner")?.GetComponent<Image>();
            if (txtTitle == null) txtTitle = transform.Find("Ribbon_Banner/Txt_Title")?.GetComponent<TextMeshProUGUI>();
            if (btnClose == null) btnClose = transform.Find("Btn_close")?.GetComponent<Button>();

            if (trackBox == null) trackBox = transform.Find("Paper_Panel/Mini_Track_Box")?.GetComponent<RectTransform>();
            if (imgTrackBox == null && trackBox != null) imgTrackBox = trackBox.GetComponent<Image>();
            if (miniTrain == null) miniTrain = transform.Find("Paper_Panel/Mini_Track_Box/Mini_Train")?.GetComponent<RectTransform>();
            if (imgMiniTrain == null && miniTrain != null) imgMiniTrain = miniTrain.GetComponent<Image>();

            if (txtStatus == null) txtStatus = transform.Find("Paper_Panel/Txt_Status")?.GetComponent<TextMeshProUGUI>();
            if (timerBox == null) timerBox = transform.Find("Paper_Panel/Timer_Box")?.gameObject;
            if (imgTimerBox == null && timerBox != null) imgTimerBox = timerBox.GetComponent<Image>();
            if (txtTimer == null) txtTimer = transform.Find("Paper_Panel/Timer_Box/Txt_Time")?.GetComponent<TextMeshProUGUI>();
            if (imgProgressBar == null) imgProgressBar = transform.Find("Paper_Panel/Progress_Bar/Fill")?.GetComponent<Image>();

            if (cargoChipsContainer == null) cargoChipsContainer = transform.Find("Paper_Panel/Cargo_Chips")?.gameObject;
            if (cargoChipsContainer != null)
            {
                for (int i = 0; i < 3; i++)
                {
                    var c = cargoChipsContainer.transform.Find($"Chip_{i + 1}");
                    if (c != null)
                    {
                        chipContainers[i] = c.GetComponent<Image>();
                        chipIcons[i] = c.Find("Img_Icon")?.GetComponent<Image>();
                        chipAmounts[i] = c.Find("Txt_Amount")?.GetComponent<TextMeshProUGUI>();
                    }
                }
            }

            if (btnSpeedUp == null) btnSpeedUp = transform.Find("Paper_Panel/Btn_SpeedUp")?.GetComponent<Button>();
            if (imgSpeedUp == null && btnSpeedUp != null) imgSpeedUp = btnSpeedUp.GetComponent<Image>();
            if (txtSpeedUp == null) txtSpeedUp = transform.Find("Paper_Panel/Btn_SpeedUp/Txt_SpeedUp")?.GetComponent<TextMeshProUGUI>();

            if (btnRaGa == null) btnRaGa = transform.Find("Paper_Panel/Btn_RaGa")?.GetComponent<Button>();
            if (imgRaGa == null && btnRaGa != null) imgRaGa = btnRaGa.GetComponent<Image>();
            if (txtRaGa == null) txtRaGa = transform.Find("Paper_Panel/Btn_RaGa/Txt_RaGa")?.GetComponent<TextMeshProUGUI>();
        }
    }
}
