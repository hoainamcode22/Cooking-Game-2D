using System.Text;
using UnityEditor;
using UnityEngine;

/// <summary>
/// Editor Tool: Tools/Farm Game/Tourist Boat/Dịch bến sát bờ  (BOAT-002 §3.7)
///
/// Cửa sổ nhỏ để DỊCH điểm đậu (Berth) của cả 3 bến vào GẦN BỜ hơn — V2 muốn tàu
/// đậu sát bờ để tấm gỗ (gangplank) bắc tới đất liền cho khách xuống.
///
/// Vì sao cần tool: Berth là con của Dock_XX, kéo tay từng cái trong Scene view
/// vừa lâu vừa dễ lệch nhau; tool dịch cả 3 bến CÙNG một offset nên hàng bến vẫn
/// thẳng đều như bố cục Sếp đã canh.
///
/// HƯỚNG BỜ suy thế nào: hierarchy do TouristBoatSetupTool sinh có BlindPoint
/// (điểm mù ngoài khơi, offset mặc định -2600,-1800 so với bến → biển nằm phía
/// DƯỚI-TRÁI) và Berth (điểm đậu trên cầu cảng). Vector BlindPoint → Berth chính
/// là hướng "từ biển vào bờ"; đi tiếp theo hướng đó là vào gần bờ hơn. Nút
/// "Tự suy hướng bờ" tính sẵn offset = hướng đó × khoảng cách bạn nhập.
/// Scene nào không suy được (thiếu BlindPoint/Berth, hoặc 2 điểm trùng nhau) thì
/// tool báo rõ và để Sếp tự nhập Vector2 offset bằng tay.
///
/// Mọi thay đổi đều qua Undo.RecordObject → Ctrl+Z hoàn tác được; ngoài ra cửa sổ
/// có sẵn nút "Hoàn tác lần dịch vừa rồi" (dịch ngược đúng offset đã áp).
/// Tool KHÔNG đụng dữ liệu runtime, KHÔNG sửa config — chỉ transform trong scene.
/// </summary>
public class BoatShoreAdjustTool : EditorWindow
{
    private const string MenuPath = "Tools/Farm Game/Tourist Boat/Dịch bến sát bờ";
    private const string RootName = "BoatSystem";
    private const string UndoLabel = "Tourist Boat — Dịch bến sát bờ";

    /// <summary>Khoảng dịch mặc định (unit world) khi bấm "Tự suy hướng bờ" — map dùng toạ độ lớn (~740 unit giữa 2 bến).</summary>
    private const float DefaultShoreDistance = 150f;

    // ─── Trạng thái cửa sổ ───────────────────────────────────────────────

    [Tooltip("Độ dịch của Berth theo world (x, y).")]
    private Vector2 _offset = Vector2.zero;

    /// <summary>Khoảng cách dùng cho nút tự suy hướng bờ.</summary>
    private float _shoreDistance = DefaultShoreDistance;

    /// <summary>Có dịch theo cả N waypoint CUỐI của path không (tránh path gãy khúc ở đoạn cuối).</summary>
    private bool _moveTailWaypoints = true;

    /// <summary>Số waypoint cuối được dịch theo (1 là đủ cho path 3 WP mặc định).</summary>
    private int _tailWaypointCount = 1;

    /// <summary>Offset đã áp gần nhất — cho nút hoàn tác nhanh trong cửa sổ.</summary>
    private Vector2 _lastApplied = Vector2.zero;
    private bool    _hasApplied;

    private Vector2 _scroll;
    private string  _status = "Chưa chạy lần nào.";

    [MenuItem(MenuPath, false, 12)]
    public static void Open()
    {
        var win = GetWindow<BoatShoreAdjustTool>(true, "Dịch bến sát bờ", true);
        win.minSize = new Vector2(430f, 430f);
        win.SuggestOffsetFromScene(silent: true);
        win.Show();
    }

    // ─── GUI ─────────────────────────────────────────────────────────────

    private void OnGUI()
    {
        _scroll = EditorGUILayout.BeginScrollView(_scroll);

        EditorGUILayout.LabelField("Dịch điểm đậu (Berth) của cả 3 bến", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox(
            "Dùng để kéo tàu ĐẬU SÁT BỜ hơn (V2: khách phải bước từ tàu qua tấm gỗ lên bờ).\n\n" +
            "Tool dịch object Berth của Dock_01/02/03 cùng một offset. Tàu bám theo Berth nên " +
            "khi Play tàu sẽ đậu ở vị trí mới.\n\n" +
            "Ctrl+Z hoàn tác được. Nhớ Ctrl+S lưu scene sau khi ưng ý.",
            MessageType.Info);

        EditorGUILayout.Space();
        EditorGUILayout.LabelField("1) Chọn độ dịch", EditorStyles.boldLabel);
        _offset = EditorGUILayout.Vector2Field("Offset (unit world)", _offset);

        EditorGUILayout.BeginHorizontal();
        _shoreDistance = EditorGUILayout.FloatField("Khoảng dịch vào bờ", _shoreDistance);
        if (GUILayout.Button("Tự suy hướng bờ", GUILayout.Width(140f)))
            SuggestOffsetFromScene(silent: false);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.HelpBox(
            "\"Tự suy hướng bờ\" = lấy hướng BlindPoint (ngoài khơi) → Berth rồi đi tiếp đúng " +
            "khoảng cách trên, tức là tiến sâu hơn về phía bờ. Không suy được thì tự nhập Offset.",
            MessageType.None);

        EditorGUILayout.Space();
        EditorGUILayout.LabelField("2) Path có dịch theo không", EditorStyles.boldLabel);
        _moveTailWaypoints = EditorGUILayout.Toggle("Dịch cả WP cuối", _moveTailWaypoints);
        using (new EditorGUI.DisabledScope(!_moveTailWaypoints))
        {
            _tailWaypointCount = Mathf.Max(1, EditorGUILayout.IntField("Số WP cuối dịch theo", _tailWaypointCount));
        }
        EditorGUILayout.HelpBox(
            "Berth dịch mà WP cuối đứng yên thì đoạn cuối đường tàu bị gãy nhẹ. Bật tùy chọn này " +
            "để WP cuối đi theo Berth (mặc định 1 WP là đủ với path 3 WP do tool sinh).",
            MessageType.None);

        EditorGUILayout.Space();
        EditorGUILayout.LabelField("3) Áp dụng", EditorStyles.boldLabel);

        using (new EditorGUI.DisabledScope(_offset.sqrMagnitude < 0.0001f))
        {
            if (GUILayout.Button("ÁP DỤNG cho 3 bến", GUILayout.Height(30f)))
                Apply(_offset, isUndo: false);
        }

        using (new EditorGUI.DisabledScope(!_hasApplied))
        {
            if (GUILayout.Button($"Hoàn tác lần dịch vừa rồi ({_lastApplied.x:0}, {_lastApplied.y:0})"))
                Apply(-_lastApplied, isUndo: true);
        }

        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Kết quả", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox(_status, MessageType.None);

        EditorGUILayout.Space();
        EditorGUILayout.HelpBox(
            "SAU KHI DỊCH:\n" +
            "• Bấm menu \"10. Canh Tau Vao O Dau\" để tàu snap về chỗ đậu mới trong Edit Mode.\n" +
            "• Nhìn scene chỉnh tay lần cuối cho khớp mép bờ (bước REVIEW của Sếp).\n" +
            "• Gangplank (tấm gỗ) của Dev B đặt theo Berth nên tự đi theo.",
            MessageType.Info);

        EditorGUILayout.EndScrollView();
    }

    // ─── Suy hướng bờ ────────────────────────────────────────────────────

    /// <summary>
    /// Tính offset gợi ý = hướng (BlindPoint → Berth) chuẩn hóa × _shoreDistance,
    /// lấy trung bình hướng của các bến tìm được. Không suy được thì giữ nguyên
    /// offset đang nhập và báo lý do (silent = true thì chỉ ghi vào _status).
    /// </summary>
    private void SuggestOffsetFromScene(bool silent)
    {
        GameObject root = FindBoatSystem();
        if (root == null)
        {
            _status = "Không tìm thấy " + RootName + " trong scene — hãy tự nhập Offset bằng tay.";
            if (!silent) EditorUtility.DisplayDialog("Dịch bến sát bờ", _status, "OK");
            return;
        }

        Transform blind = root.transform.Find("BlindPoint");
        if (blind == null)
        {
            _status = "Thiếu BlindPoint dưới " + RootName + " — không suy được hướng bờ, hãy tự nhập Offset.";
            if (!silent) EditorUtility.DisplayDialog("Dịch bến sát bờ", _status, "OK");
            return;
        }

        Vector2 sum = Vector2.zero;
        int found = 0;
        for (int i = 0; i < 3; i++)
        {
            Transform berth = FindBerth(root.transform, i);
            if (berth == null) continue;

            Vector2 dir = (Vector2)(berth.position - blind.position);
            if (dir.sqrMagnitude < 0.0001f) continue; // Berth trùng BlindPoint — bỏ qua bến này

            sum += dir.normalized;
            found++;
        }

        if (found == 0)
        {
            _status = "Không bến nào suy được hướng (thiếu Berth hoặc Berth trùng BlindPoint) — hãy tự nhập Offset.";
            if (!silent) EditorUtility.DisplayDialog("Dịch bến sát bờ", _status, "OK");
            return;
        }

        Vector2 shoreDir = (sum / found).normalized;
        _offset = shoreDir * Mathf.Abs(_shoreDistance);
        _status = $"Hướng vào bờ suy từ {found} bến: ({shoreDir.x:0.00}, {shoreDir.y:0.00}) — " +
                  $"offset gợi ý ({_offset.x:0}, {_offset.y:0}).";
        Repaint();
    }

    // ─── Áp dụng ─────────────────────────────────────────────────────────

    /// <summary>
    /// Dịch Berth (và N WP cuối nếu bật) của cả 3 bến theo offset, mỗi object đều
    /// Undo.RecordObject trước khi ghi. Log chi tiết ra Console: bến nào dịch từ
    /// đâu tới đâu, WP nào đi theo, bến nào bị bỏ qua vì thiếu object.
    /// </summary>
    private void Apply(Vector2 offset, bool isUndo)
    {
        GameObject root = FindBoatSystem();
        if (root == null)
        {
            _status = "Không tìm thấy " + RootName + " trong scene — chưa dịch được gì.";
            EditorUtility.DisplayDialog("Dịch bến sát bờ", _status, "OK");
            return;
        }

        Undo.IncrementCurrentGroup();
        Undo.SetCurrentGroupName(UndoLabel);

        Vector3 delta = new Vector3(offset.x, offset.y, 0f);
        var log = new StringBuilder();
        int movedBerths = 0, movedWps = 0;

        for (int i = 0; i < 3; i++)
        {
            Transform dock = root.transform.Find(string.Format("Dock_{0:00}", i + 1));
            if (dock == null)
            {
                log.AppendLine($"- Dock_{i + 1:00}: không có trong scene — bỏ qua.");
                continue;
            }

            Transform berth = dock.Find("Berth");
            if (berth == null)
            {
                log.AppendLine($"- Dock_{i + 1:00}: thiếu con \"Berth\" — bỏ qua.");
                continue;
            }

            Vector3 from = berth.position;
            Undo.RecordObject(berth, UndoLabel);
            berth.position = from + delta;
            EditorUtility.SetDirty(berth);
            movedBerths++;
            log.AppendLine($"- Dock_{i + 1:00}/Berth: ({from.x:0}, {from.y:0}) → ({berth.position.x:0}, {berth.position.y:0})");

            if (!_moveTailWaypoints) continue;

            Transform path = dock.Find("Path");
            if (path == null || path.childCount == 0)
            {
                log.AppendLine($"    (Dock_{i + 1:00} chưa có waypoint — chỉ dịch Berth)");
                continue;
            }

            // WP cuối = con cuối cùng của Path (tool sinh theo thứ tự WP_01..WP_n).
            int take = Mathf.Clamp(_tailWaypointCount, 1, path.childCount);
            for (int k = path.childCount - take; k < path.childCount; k++)
            {
                Transform wp = path.GetChild(k);
                if (wp == null) continue;

                Vector3 wpFrom = wp.position;
                Undo.RecordObject(wp, UndoLabel);
                wp.position = wpFrom + delta;
                EditorUtility.SetDirty(wp);
                movedWps++;
                log.AppendLine($"    + {wp.name}: ({wpFrom.x:0}, {wpFrom.y:0}) → ({wp.position.x:0}, {wp.position.y:0})");
            }
        }

        Undo.CollapseUndoOperations(Undo.GetCurrentGroup());

        if (movedBerths == 0)
        {
            _status = "Không dịch được bến nào (xem Console).";
            Debug.LogWarning("[TouristBoat] Dịch bến sát bờ: không dịch được bến nào.\n" + log);
            EditorUtility.DisplayDialog("Dịch bến sát bờ", _status + "\n\nChi tiết ở Console.", "OK");
            return;
        }

        if (isUndo)
        {
            _hasApplied = false;
            _status = $"Đã hoàn tác: dịch ngược ({offset.x:0}, {offset.y:0}) cho {movedBerths} bến, {movedWps} waypoint.";
        }
        else
        {
            _lastApplied = offset;
            _hasApplied  = true;
            _status = $"Đã dịch {movedBerths} bến + {movedWps} waypoint theo ({offset.x:0}, {offset.y:0}).";
        }

        Debug.Log($"[TouristBoat] Dịch bến sát bờ — offset ({offset.x:0}, {offset.y:0}), " +
                  $"{movedBerths} Berth + {movedWps} WP:\n{log}");
        Repaint();
    }

    // ─── Helpers ─────────────────────────────────────────────────────────

    private static Transform FindBerth(Transform root, int dockIndex)
    {
        Transform dock = root.Find(string.Format("Dock_{0:00}", dockIndex + 1));
        return dock != null ? dock.Find("Berth") : null;
    }

    /// <summary>Tìm BoatSystem trong scene đang mở — ưu tiên theo component, fallback theo tên (kể cả đang tắt).</summary>
    private static GameObject FindBoatSystem()
    {
        var mgr = Object.FindFirstObjectByType<BoatDockManager>(FindObjectsInactive.Include);
        if (mgr != null) return mgr.gameObject;

        foreach (Transform t in Object.FindObjectsByType<Transform>(
                     FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            if (t != null && t.parent == null && t.name == RootName)
                return t.gameObject;
        }
        return null;
    }
}
