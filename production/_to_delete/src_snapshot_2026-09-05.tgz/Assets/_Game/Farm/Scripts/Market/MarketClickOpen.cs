using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class MarketClickOpen : MonoBehaviour
{
    [SerializeField] private MarketPopupUI marketPopupUI;
    [SerializeField] private MarketManager marketManager;
    [SerializeField] private Camera mainCamera;
    [SerializeField] private Collider2D targetCollider;

    private void Awake()
    {
        // tự lấy ref
        if (mainCamera == null)
            mainCamera = Camera.main;

        if (targetCollider == null)
            targetCollider = GetComponent<Collider2D>();

        if (marketManager == null)
            marketManager = MarketManager.Instance;

        if (marketManager == null)
            marketManager = FindAnyObjectByType<MarketManager>(FindObjectsInactive.Include);
    }

    private void Update()
    {
        if (TryGetPointerScreenPosition(out Vector2 screenPos))
        {
            TryOpenMarket(screenPos);
        }
    }

    // lấy vị trí click / touch
    private bool TryGetPointerScreenPosition(out Vector2 screenPos)
    {
        screenPos = default;

        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            screenPos = Mouse.current.position.ReadValue();
            return true;
        }

        if (Touchscreen.current != null && Touchscreen.current.primaryTouch.press.wasPressedThisFrame)
        {
            screenPos = Touchscreen.current.primaryTouch.position.ReadValue();
            return true;
        }

        return false;
    }

    // mở chợ
    private void TryOpenMarket(Vector2 screenPos)
    {
        if (FarmInputLock.BlockWorldInteraction) return;
        if (SceneManager.GetSceneByName("SampleScene").isLoaded)
            return;

        // Không mở khi Edit Mode đang bật
        if (EditModeManager.IsEditMode) return;

        if (FarmInputLock.BlockMapPan) return;

        // Không mở khi đang có popup khác mở
        if (PopupManager.Instance != null && PopupManager.Instance.IsAnyPopupOpen())
            return;

        if (IsPointerOverPopupUI(screenPos))
            return;

        if (mainCamera == null)
        {
            return;
        }

        if (targetCollider == null)
        {
            return;
        }

        if (marketManager == null)
            marketManager = MarketManager.Instance;

        if (marketManager == null && marketPopupUI == null)
        {
            return;
        }

        Vector3 world3 = mainCamera.ScreenToWorldPoint(screenPos);
        Vector2 world2 = new Vector2(world3.x, world3.y);

        bool hit = targetCollider.OverlapPoint(world2);

        if (!hit)
return;

        if (marketManager != null)
            marketManager.OpenMarketPopup();
        else
            marketPopupUI.OpenPopup();
    }

    // check có bấm vào UI popup không
    private bool IsPointerOverPopupUI(Vector2 screenPos)
    {
        if (EventSystem.current == null)
            return false;

        PointerEventData eventData = new PointerEventData(EventSystem.current);
        eventData.position = screenPos;

        List<RaycastResult> results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData, results);

        for (int i = 0; i < results.Count; i++)
        {
            // SỬA 21/08 — đồng bộ với WarehouseClickOpen (dòng 107 bên đó):
            // KHÔNG chặn khi không có popup nào đang mở. Thiếu dòng này, một graphic
            // "mồ côi" còn active dưới Canvas_MarketPopup (popup đóng dở, panel quên tắt)
            // sẽ thành BỨC TƯỜNG TÀNG HÌNH chặn vĩnh viễn cú click mở lại chợ —
            // đúng ca F9 debug bắt được: Panel_Dim active vô hình đè giữa màn hình.
            if (PopupManager.Instance != null && !PopupManager.Instance.IsAnyPopupOpen())
                continue;

            Transform t = results[i].gameObject.transform;
            Canvas parentCanvas = t.GetComponentInParent<Canvas>();

            // Thêm "Canvas_StallPopup": quầy hàng là popup mới, nếu không liệt kê ở đây thì
            // click lên popup quầy sẽ XUYÊN QUA và mở luôn chợ chồng lên trên.
            if (parentCanvas != null && (parentCanvas.name == "Canvas_Popup"
                                      || parentCanvas.name == "Canvas_MarketPopup"
                                      || parentCanvas.name == "Canvas_StallPopup"))
                return true;
        }

        return false;
    }
}
