using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.U2D.Sprites;
using UnityEngine;

/// <summary>
/// TOOL 1 — CẮT (SLICE) 3 SPRITESHEET NHÂN VẬT.
///
/// Menu:
///   Tools/Farm Game/Characters/★ Slice 3 spritesheet nhân vật (DRY-RUN)
///   Tools/Farm Game/Characters/★ Slice 3 spritesheet nhân vật (APPLY)
///   Tools/Farm Game/Characters/Kiểm tra sprite con đã slice
///
/// LÀM GÌ
///   • Đặt TextureImporter cho 3 file PNG nhân vật: Sprite · Multiple · PPU 100 ·
///     pivot Bottom-Center · alphaIsTransparency · mipmap OFF · filter Bilinear.
///   • Cắt lưới đúng chỉ số §5 CONTRACT rồi đặt TÊN CỐ ĐỊNH cho từng ô:
///       flowergirl_walk_spritesheet.png  848×1264  3 cột × 4 hàng
///           hàng 0 → fg_down_1..3 · hàng 1 → fg_left_1..3
///           hàng 2 → fg_right_1..3 · hàng 3 → fg_up_1..3
///       worker_hammer_spritesheet.png    1200×896  4 cột × 3 hàng → hammer_01..12
///       worker_celebrate_spritesheet.png 1200×896  4 cột × 3 hàng → celebrate_01..12
///     (thứ tự đọc: trái → phải, trên → dưới)
///
/// VÌ SAO CHIA RANH GIỚI BẰNG RoundToInt(index * size / count)
///   Cell không chia hết số nguyên (848/3 = 282.667 · 896/3 = 298.667). Nếu lấy
///   cellW = 282 rồi nhân dần thì cột cuối lệch 2px và sai số DỒN. Cách này tính
///   ranh giới tuyệt đối cho từng mép nên tổng bề rộng luôn đúng bằng ảnh, ô cuối
///   tự nhận phần dư.
///
/// VÌ SAO DÙNG SpriteDataProviderFactories CHỨ KHÔNG TextureImporter.spritesheet
///   `TextureImporter.spritesheet` đã deprecated. Dự án đã có tiền lệ chạy tốt với
///   API mới (Assets/NV_CHEF/Editor/ChefSetupTool.cs, Assets/NV_01/Editor/SetupPlayerNV01.cs)
///   nên chắc chắn package com.unity.2d.sprite có mặt. Quan trọng hơn:
///   ISpriteNameFileIdDataProvider cho phép GIỮ NGUYÊN fileID theo TÊN sprite ⇒
///   chạy tool lần 2 KHÔNG làm prefab/asset đang trỏ vào sprite bị "missing".
///
/// IDEMPOTENT: SetSpriteRects THAY THẾ toàn bộ danh sách (không merge) và tên sprite
/// là cố định ⇒ chạy 10 lần vẫn đúng 12 sprite con, không nhân đôi.
/// </summary>
public static class CharacterSheetSliceTool
{
    // ─── Menu ────────────────────────────────────────────────────────────
    private const string MenuRoot  = "Tools/Farm Game/Characters/";
    private const string MenuDry   = MenuRoot + "★ Slice 3 spritesheet nhân vật (DRY-RUN)";
    private const string MenuApply = MenuRoot + "★ Slice 3 spritesheet nhân vật (APPLY)";
    private const string MenuCheck = MenuRoot + "Kiểm tra sprite con đã slice";

    private const string Tag = "[Tool]";

    // ─── Hằng số CHỈNH ĐƯỢC ──────────────────────────────────────────────
    private const float PixelsPerUnit = 100f;

    // ─── Đường dẫn 3 sheet (public để tool khác dùng lại, khỏi gõ lại chuỗi) ──
    public const string PathFlowerGirl = "Assets/Art/Characters/FlowerGirl/flowergirl_walk_spritesheet.png";
    public const string PathHammer     = "Assets/Art/Characters/Worker/worker_hammer_spritesheet.png";
    public const string PathCelebrate  = "Assets/Art/Characters/Worker/worker_celebrate_spritesheet.png";

    /// <summary>Số sprite con mong đợi ở MỖI sheet.</summary>
    public const int ExpectedSpritesPerSheet = 12;

    // ─────────────────────────────────────────────────────────────────────
    //  MÔ TẢ 1 SHEET
    // ─────────────────────────────────────────────────────────────────────
    private sealed class SheetSpec
    {
        public string   path;
        public string   nhan;        // tên ngắn để in report
        public int      cols;
        public int      rows;
        public int      expectedW;   // kích thước §5 CONTRACT đã đo
        public int      expectedH;
        public string[] names;       // cols*rows tên, đọc trái→phải, trên→dưới
    }

    private static SheetSpec[] BuildSpecs()
    {
        // FlowerGirl: 3 cột × 4 hàng, mỗi hàng 1 hướng.
        var fgNames = new string[12];
        string[] huong = { "down", "left", "right", "up" };
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 3; c++)
                fgNames[r * 3 + c] = "fg_" + huong[r] + "_" + (c + 1);

        // Worker: 4 cột × 3 hàng, đánh số phẳng 01..12.
        var hammerNames    = new string[12];
        var celebrateNames = new string[12];
        for (int i = 0; i < 12; i++)
        {
            hammerNames[i]    = "hammer_"    + (i + 1).ToString("00");
            celebrateNames[i] = "celebrate_" + (i + 1).ToString("00");
        }

        return new[]
        {
            new SheetSpec { path = PathFlowerGirl, nhan = "FlowerGirl walk",
                            cols = 3, rows = 4, expectedW = 848,  expectedH = 1264, names = fgNames },
            new SheetSpec { path = PathHammer,     nhan = "Worker hammer",
                            cols = 4, rows = 3, expectedW = 1200, expectedH = 896,  names = hammerNames },
            new SheetSpec { path = PathCelebrate,  nhan = "Worker celebrate",
                            cols = 4, rows = 3, expectedW = 1200, expectedH = 896,  names = celebrateNames },
        };
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MENU: DRY-RUN
    // ─────────────────────────────────────────────────────────────────────
    [MenuItem(MenuDry, false, 10)]
    public static void DryRun()
    {
        var specs = BuildSpecs();
        var sb    = new StringBuilder();
        sb.AppendLine(Tag + " CharacterSheetSliceTool — DRY-RUN (không ghi gì lên đĩa)");
        sb.AppendLine("─────────────────────────────────────────────────────────────");

        int okFile = 0, thieuFile = 0, canhBao = 0;

        for (int i = 0; i < specs.Length; i++)
        {
            SheetSpec s = specs[i];
            sb.AppendLine();
            sb.AppendLine($"[{i + 1}/{specs.Length}] {s.nhan}");
            sb.AppendLine("   file      : " + s.path);

            int w, h;
            if (!TryReadPngSize(s.path, out w, out h))
            {
                sb.AppendLine("   ✖ KHÔNG đọc được file (thiếu hoặc không phải PNG hợp lệ).");
                sb.AppendLine("     CẦN LÀM: kiểm tra lại đường dẫn art rồi chạy lại menu này.");
                thieuFile++;
                continue;
            }
            okFile++;

            sb.AppendLine($"   kích thước thật : {w} × {h} px");
            sb.AppendLine($"   §5 CONTRACT     : {s.expectedW} × {s.expectedH} px");

            if (w != s.expectedW || h != s.expectedH)
            {
                canhBao++;
                sb.AppendLine("   ⚠ CẢNH BÁO: kích thước KHÁC §5 — art có thể đã bị thay/nén. " +
                              "Tool vẫn cắt đúng theo kích thước THẬT (grid tỉ lệ), " +
                              "nhưng hãy xác nhận lại với Lead.");
            }

            float cellW = (float)w / s.cols;
            float cellH = (float)h / s.rows;
            sb.AppendLine($"   grid dự kiến    : {s.cols} cột × {s.rows} hàng · cell {cellW:0.###} × {cellH:0.###} px");

            Rect[] rects = ComputeRects(w, h, s.cols, s.rows);
            sb.AppendLine($"   {s.names.Length} tên sprite con + rect:");
            for (int k = 0; k < s.names.Length; k++)
            {
                Rect r = rects[k];
                sb.AppendLine($"      {(k + 1),2}. {s.names[k],-16} rect=({r.x:0},{r.y:0},{r.width:0},{r.height:0})");
            }

            int dangCo = DemSpriteCon(s.path);
            sb.AppendLine($"   sprite con hiện có trên đĩa: {dangCo}" +
                          (dangCo == s.names.Length ? " (đã slice trước đó — APPLY sẽ ghi đè, KHÔNG nhân đôi)"
                                                    : " (APPLY sẽ tạo mới)"));
        }

        sb.AppendLine();
        sb.AppendLine("─────────────────────────────────────────────────────────────");
        sb.AppendLine($"{Tag} TỔNG KẾT DRY-RUN: đọc được {okFile}/{specs.Length} file · " +
                      $"thiếu {thieuFile} · cảnh báo kích thước {canhBao}. " +
                      "Chưa ghi gì — bấm menu (APPLY) để cắt thật.");
        Debug.Log(sb.ToString());
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MENU: APPLY
    // ─────────────────────────────────────────────────────────────────────
    [MenuItem(MenuApply, false, 11)]
    public static void Apply()
    {
        var specs = BuildSpecs();
        var sb    = new StringBuilder();
        sb.AppendLine(Tag + " CharacterSheetSliceTool — APPLY");
        sb.AppendLine("─────────────────────────────────────────────────────────────");

        int daCat = 0, boQua = 0, tongSprite = 0;

        for (int i = 0; i < specs.Length; i++)
        {
            SheetSpec s = specs[i];
            sb.AppendLine();
            sb.AppendLine($"[{i + 1}/{specs.Length}] {s.nhan} — {s.path}");

            int w, h;
            if (!TryReadPngSize(s.path, out w, out h))
            {
                sb.AppendLine("   ✖ BỎ QUA: không đọc được file PNG.");
                sb.AppendLine("     CẦN LÀM: đặt art đúng đường dẫn trên rồi chạy lại.");
                boQua++;
                continue;
            }

            if (w != s.expectedW || h != s.expectedH)
                sb.AppendLine($"   ⚠ kích thước {w}×{h} khác §5 ({s.expectedW}×{s.expectedH}) — " +
                              "vẫn cắt theo kích thước THẬT.");

            string loi;
            int soSprite;
            if (!CatMotSheet(s, w, h, out soSprite, out loi))
            {
                sb.AppendLine("   ✖ BỎ QUA: " + loi);
                boQua++;
                continue;
            }

            daCat++;
            tongSprite += soSprite;
            sb.AppendLine($"   ✔ đã cắt {soSprite} sprite con · pivot Bottom-Center · " +
                          $"PPU {PixelsPerUnit:0} · alphaIsTransparency ON · mipmap OFF · filter Bilinear.");

            // Xác minh NGAY: đọc lại sprite thật trong PNG, đối chiếu tên.
            List<string> thieuTen, laTen;
            KiemTenSprite(s, out thieuTen, out laTen);
            if (thieuTen.Count > 0)
                sb.AppendLine("   ⚠ thiếu sprite sau khi cắt: " + string.Join(", ", thieuTen));
            if (laTen.Count > 0)
                sb.AppendLine("   ⚠ còn sprite LẠ (tên cũ) trong file: " + string.Join(", ", laTen) +
                              " — mở Sprite Editor xoá tay nếu thấy khó chịu, không ảnh hưởng tool.");
            if (thieuTen.Count == 0 && laTen.Count == 0)
                sb.AppendLine("   ✔ xác minh tên sprite: khớp 100%.");
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        sb.AppendLine();
        sb.AppendLine("─────────────────────────────────────────────────────────────");
        sb.AppendLine($"{Tag} TỔNG KẾT APPLY: cắt xong {daCat}/{specs.Length} sheet · " +
                      $"bỏ qua {boQua} · tổng {tongSprite} sprite con. " +
                      (boQua == 0
                          ? "Bước tiếp: Tools/Farm Game/Worker/★ SETUP thợ búa và Tools/Farm Game/Shipper/★ SETUP cô gái giỏ hoa."
                          : "Sửa các dòng ✖ ở trên rồi chạy lại menu này."));
        Debug.Log(sb.ToString());
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MENU: KIỂM TRA
    // ─────────────────────────────────────────────────────────────────────
    [MenuItem(MenuCheck, false, 12)]
    public static void KiemTra()
    {
        var specs = BuildSpecs();
        var sb    = new StringBuilder();
        sb.AppendLine(Tag + " CharacterSheetSliceTool — KIỂM TRA sprite con đã slice");
        sb.AppendLine("─────────────────────────────────────────────────────────────");

        int du = 0;
        for (int i = 0; i < specs.Length; i++)
        {
            SheetSpec s = specs[i];
            var ten = new List<string>();
            Object[] all = AssetDatabase.LoadAllAssetsAtPath(s.path);
            if (all != null)
            {
                for (int k = 0; k < all.Length; k++)
                {
                    var sp = all[k] as Sprite;
                    if (sp != null) ten.Add(sp.name);
                }
            }
            ten.Sort(System.StringComparer.Ordinal);

            bool okSo = ten.Count == s.names.Length;
            if (okSo) du++;

            sb.AppendLine();
            sb.AppendLine($"{(okSo ? "✅" : "❌")} {s.nhan} — {ten.Count}/{s.names.Length} sprite con");
            sb.AppendLine("   " + s.path);
            sb.AppendLine("   " + (ten.Count == 0 ? "(chưa slice — chạy menu APPLY)" : string.Join(", ", ten)));
        }

        sb.AppendLine();
        sb.AppendLine("─────────────────────────────────────────────────────────────");
        sb.AppendLine($"{Tag} TỔNG KẾT KIỂM TRA: {du}/{specs.Length} sheet đủ {ExpectedSpritesPerSheet} sprite con.");
        Debug.Log(sb.ToString());
    }

    // ─────────────────────────────────────────────────────────────────────
    //  LÕI CẮT 1 SHEET
    // ─────────────────────────────────────────────────────────────────────
    private static bool CatMotSheet(SheetSpec s, int w, int h, out int soSprite, out string loi)
    {
        soSprite = 0;
        loi      = null;

        var importer = AssetImporter.GetAtPath(s.path) as TextureImporter;
        if (importer == null)
        {
            loi = s.path + " không phải texture (TextureImporter = null).";
            return false;
        }

        Undo.RecordObject(importer, "Slice character spritesheet");

        importer.textureType         = TextureImporterType.Sprite;
        importer.spriteImportMode    = SpriteImportMode.Multiple;
        importer.spritePixelsPerUnit = PixelsPerUnit;
        importer.alphaIsTransparency = true;
        importer.mipmapEnabled       = false;
        importer.filterMode          = FilterMode.Bilinear;
        importer.sRGBTexture         = true;
        importer.npotScale           = TextureImporterNPOTScale.None;
        importer.textureCompression  = TextureImporterCompression.Uncompressed;
        // maxTextureSize phải >= cạnh lớn nhất, không thì Unity co ảnh xuống và
        // rect cắt theo kích thước gốc sẽ lệch.
        importer.maxTextureSize = Mathf.Max(2048, Mathf.NextPowerOfTwo(Mathf.Max(w, h)));

        var ts = new TextureImporterSettings();
        importer.ReadTextureSettings(ts);
        ts.spriteMeshType  = SpriteMeshType.FullRect;                  // mesh = đúng rect
        ts.spriteAlignment = (int)SpriteAlignment.BottomCenter;        // §2: chân chạm đất
        importer.SetTextureSettings(ts);
        importer.SaveAndReimport();

        // Lấy lại importer SAU reimport để data provider đọc đúng trạng thái Multiple.
        importer = AssetImporter.GetAtPath(s.path) as TextureImporter;
        if (importer == null)
        {
            loi = "mất TextureImporter sau SaveAndReimport (" + s.path + ").";
            return false;
        }

        var factory = new SpriteDataProviderFactories();
        factory.Init();
        ISpriteEditorDataProvider dp = factory.GetSpriteEditorDataProviderFromObject(importer);
        if (dp == null)
        {
            loi = "thiếu package '2D Sprite' (com.unity.2d.sprite) — không lấy được ISpriteEditorDataProvider.";
            return false;
        }
        dp.InitSpriteEditorDataProvider();

        // Giữ fileID cũ theo TÊN ⇒ cắt lại không làm prefab/asset mất tham chiếu sprite.
        var guidCu = new Dictionary<string, GUID>();
        SpriteRect[] cu = dp.GetSpriteRects();
        if (cu != null)
        {
            for (int i = 0; i < cu.Length; i++)
                if (cu[i] != null && !guidCu.ContainsKey(cu[i].name))
                    guidCu[cu[i].name] = cu[i].spriteID;
        }

        Rect[] rects = ComputeRects(w, h, s.cols, s.rows);
        var moi   = new List<SpriteRect>(rects.Length);
        var pairs = new List<SpriteNameFileIdPair>(rects.Length);

        for (int i = 0; i < rects.Length && i < s.names.Length; i++)
        {
            string ten = s.names[i];
            GUID id;
            if (!guidCu.TryGetValue(ten, out id) || id.Empty()) id = GUID.Generate();

            var sr = new SpriteRect
            {
                name      = ten,
                spriteID  = id,
                rect      = rects[i],
                alignment = SpriteAlignment.BottomCenter,
                pivot     = new Vector2(0.5f, 0f),
                border    = Vector4.zero,
            };
            moi.Add(sr);
            pairs.Add(new SpriteNameFileIdPair(ten, id));
        }

        dp.SetSpriteRects(moi.ToArray());
        var nameProv = dp.GetDataProvider<ISpriteNameFileIdDataProvider>();
        if (nameProv != null) nameProv.SetNameFileIdPairs(pairs);
        dp.Apply();
        importer.SaveAndReimport();

        soSprite = moi.Count;
        return true;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  TIỆN ÍCH
    // ─────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Ranh giới lưới tính TUYỆT ĐỐI cho từng mép: RoundToInt(index * size / count).
    /// Không dồn sai số như cách nhân cellW đã làm tròn. Ô cuối tự lấy hết phần dư.
    /// Trả về mảng rect theo thứ tự đọc trái→phải, TRÊN→DƯỚI (hàng 0 = đỉnh ảnh),
    /// còn Rect của Unity gốc ở GÓC DƯỚI-TRÁI nên hàng r có y = h - yTop[r+1].
    /// </summary>
    private static Rect[] ComputeRects(int w, int h, int cols, int rows)
    {
        cols = Mathf.Max(1, cols);
        rows = Mathf.Max(1, rows);

        var xs = new int[cols + 1];
        for (int c = 0; c <= cols; c++) xs[c] = Mathf.RoundToInt(c * (float)w / cols);
        xs[0] = 0; xs[cols] = w;

        var yTop = new int[rows + 1];
        for (int r = 0; r <= rows; r++) yTop[r] = Mathf.RoundToInt(r * (float)h / rows);
        yTop[0] = 0; yTop[rows] = h;

        var res = new Rect[cols * rows];
        for (int r = 0; r < rows; r++)
        {
            for (int c = 0; c < cols; c++)
            {
                int x   = xs[c];
                int wid = Mathf.Max(1, xs[c + 1] - xs[c]);
                int y   = h - yTop[r + 1];
                int hei = Mathf.Max(1, yTop[r + 1] - yTop[r]);
                res[r * cols + c] = new Rect(x, y, wid, hei);
            }
        }
        return res;
    }

    /// <summary>
    /// Đọc kích thước PNG từ IHDR (byte 16..23, big-endian) — KHÔNG qua Texture2D.
    /// Vì sao: Texture2D đã import có thể bị maxTextureSize co nhỏ ⇒ đọc ra số SAI
    /// và rect cắt sẽ lệch. Đọc header là số THẬT của file art.
    /// </summary>
    private static bool TryReadPngSize(string assetPath, out int w, out int h)
    {
        w = 0; h = 0;
        if (string.IsNullOrEmpty(assetPath)) return false;

        try
        {
            if (!File.Exists(assetPath)) return false;
            using (var fs = new FileStream(assetPath, FileMode.Open, FileAccess.Read))
            {
                var b = new byte[24];
                if (fs.Read(b, 0, 24) < 24) return false;
                if (b[0] != 0x89 || b[1] != 0x50 || b[2] != 0x4E || b[3] != 0x47) return false;
                w = (b[16] << 24) | (b[17] << 16) | (b[18] << 8) | b[19];
                h = (b[20] << 24) | (b[21] << 16) | (b[22] << 8) | b[23];
                return w > 0 && h > 0;
            }
        }
        catch (System.Exception e)
        {
            Debug.LogWarning(Tag + " không đọc được header PNG " + assetPath + " — " + e.Message);
            return false;
        }
    }

    private static int DemSpriteCon(string assetPath)
    {
        Object[] all = AssetDatabase.LoadAllAssetsAtPath(assetPath);
        if (all == null) return 0;
        int n = 0;
        for (int i = 0; i < all.Length; i++) if (all[i] is Sprite) n++;
        return n;
    }

    private static void KiemTenSprite(SheetSpec s, out List<string> thieu, out List<string> la)
    {
        thieu = new List<string>();
        la    = new List<string>();

        var coTrenDia = new HashSet<string>();
        Object[] all = AssetDatabase.LoadAllAssetsAtPath(s.path);
        if (all != null)
        {
            for (int i = 0; i < all.Length; i++)
            {
                var sp = all[i] as Sprite;
                if (sp != null) coTrenDia.Add(sp.name);
            }
        }

        var mongDoi = new HashSet<string>(s.names);
        for (int i = 0; i < s.names.Length; i++)
            if (!coTrenDia.Contains(s.names[i])) thieu.Add(s.names[i]);

        foreach (string t in coTrenDia)
            if (!mongDoi.Contains(t)) la.Add(t);

        la.Sort(System.StringComparer.Ordinal);
    }

    /// <summary>
    /// Tool khác (BuilderWorkerSetupTool / ShipperSetupTool) gọi hàm này để lấy
    /// sprite con theo TÊN, khỏi phải tự lặp LoadAllAssetsAtPath.
    /// Thiếu bất kỳ tên nào ⇒ trả null (KHÔNG trả mảng lỗ để tool sau khỏi crash).
    /// </summary>
    public static Sprite[] LoadFramesByName(string assetPath, string[] names)
    {
        if (string.IsNullOrEmpty(assetPath) || names == null || names.Length == 0) return null;

        var map = new Dictionary<string, Sprite>();
        Object[] all = AssetDatabase.LoadAllAssetsAtPath(assetPath);
        if (all == null) return null;
        for (int i = 0; i < all.Length; i++)
        {
            var sp = all[i] as Sprite;
            if (sp != null && !map.ContainsKey(sp.name)) map[sp.name] = sp;
        }

        var res = new Sprite[names.Length];
        for (int i = 0; i < names.Length; i++)
        {
            Sprite sp;
            if (!map.TryGetValue(names[i], out sp) || sp == null) return null;
            res[i] = sp;
        }
        return res;
    }

    /// <summary>12 tên frame theo thứ tự §5.1 mà FourDirWalkAnimator.SetupFromFlat mong đợi.</summary>
    public static string[] FlowerGirlFrameNames()
    {
        var res = new string[12];
        string[] huong = { "down", "left", "right", "up" };
        for (int r = 0; r < 4; r++)
            for (int c = 0; c < 3; c++)
                res[r * 3 + c] = "fg_" + huong[r] + "_" + (c + 1);
        return res;
    }

    /// <summary>hammer_01..12 (hoặc celebrate_01..12) theo thứ tự đọc phẳng.</summary>
    public static string[] WorkerFrameNames(string prefix)
    {
        var res = new string[12];
        for (int i = 0; i < 12; i++) res[i] = prefix + (i + 1).ToString("00");
        return res;
    }
}
